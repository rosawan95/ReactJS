import React from 'react'
import ReactDOM from 'react-dom'
export const Nostate = ()=> {
    return (
        <div>
            <h1>this is stateless component</h1>
        </div>
    )
}
//ReactDOM.render(<Nostate/>, document.getElementById("stateless"));