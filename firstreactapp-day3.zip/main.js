import React from 'react'
import ReactDOM from 'react-dom'
//import Demo from './app.jsx'
import Home from './home.jsx'
import Contact from './contact.jsx'
import Nostate from './stateless.component.jsx'
import Events from './event.component.jsx'
import About from './about.jsx'
import {BrowserRouter as Router, Route, Switch, Link} from 'react-router-dom'
//ReactDOM.render(<Events/>, document.getElementById("app"));
//ReactDOM.render(<Demo />, document.getElementById("app"))
//ReactDOM.render(<Home/>, document.getElementById("home"));
//ReactDOM.render(<Contact />, document.getElementById("contact"))
ReactDOM.render(
    <Router>
        <div>
            <Link to={'/home'}>Home</Link>
            <Link to={'/about'}>About</Link>
            <Link to={'/contact'}>Contact</Link>
            <Switch>
                <Route exact path='/home' component={Home} />
                <Route exact path='/about' component={About} />
                <Route exact path='/contact' component={Contact} />
            </Switch>
        </div>
    </Router>, document.getElementById("app")
);