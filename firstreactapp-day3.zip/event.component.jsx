import React from 'react'
import ReactDOM from 'react-dom'
class Events extends React.Component {
    constructor() {
        super();
        this.state = {"status":false}
    }
    onGreet() {
        alert("good afternoon!")
    }
    switchIt() {
        this.setState({"status": !this.state.status});
    }
    render() {
        var b = this.state.status?"Rakesh":"Ramesh";
        return (
            <div>
                <h1>Hello, Mr. {b}</h1>
                <button onClick={()=>this.switchIt()}>Click Here</button>
                <hr/>
                <ChildEvent greet={this.onGreet}/>
            </div>
        )

    }
}
class ChildEvent extends React.Component {
    render() {
        return (
            <div>
                <button onClick={this.props.greet}>Call Parent Greet</button>
            </div>
        )
    }
}
export default Events;