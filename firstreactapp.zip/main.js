import React from 'react'
import ReactDOM from 'react-dom'
import Demo from './app.jsx'
ReactDOM.render(<Demo />, document.getElementById("app"))