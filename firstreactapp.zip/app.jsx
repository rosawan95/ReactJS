import React from 'react'
class Demo extends React.Component {
    render() {
        var styles = {
            "background-color": 'silver'
        }
        var styles2 = {
            color: 'red'
        }
        return (
            <div style={styles}>
                <h1 style={styles2}>Welcome to React JS First App</h1>
                <h2>this is my first react session</h2>
                <h3>Sum is: {2 + 3}</h3>
            </div>
        );
    }
}
export default Demo;