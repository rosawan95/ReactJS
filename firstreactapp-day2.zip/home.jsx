import React from 'react'
class Home extends React.Component {
    render() {
        return (
            <div>
                <h1>Home Component</h1>
                <p>{this.props.abc}</p>
                <p>{this.props.xyz}</p>
            </div>
        )
    }
}
export default Home;