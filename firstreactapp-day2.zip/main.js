import React from 'react'
import ReactDOM from 'react-dom'
import Demo from './app.jsx'
import Home from './home.jsx'
import Contact from './contact.jsx'
ReactDOM.render(<Demo />, document.getElementById("app"))
//ReactDOM.render(<Home/>, document.getElementById("home"));
//ReactDOM.render(<Contact />, document.getElementById("contact"))