import React from 'react'
class StateService extends React.Component {
    constructor() {
        super()
        this.state = {"user": "CVRaman", "id":123}
    }
    render() {
        setTimeout(()=>{this.setState({"user":"Ramanujan", "id":456})}, 5000);
        return (
            <p>User: {this.state.user}
                <br/>Id: {this.state.id}
            </p>

        )

    }
}
export default StateService;