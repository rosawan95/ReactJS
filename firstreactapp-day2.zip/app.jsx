import React from 'react'
import Home from './home.jsx'
import Contact from './contact.jsx'
import StateService from './state.component.jsx'
class Demo extends React.Component {
    render() {
        var hobbies = ["sports", "reading", "movies"]
        return (
            <div>
                <Home abc="home component" xyz="xyz compoent"/>
                <Contact hobbies={hobbies} />
                <StateService />
            </div>
        );
    }
}
export default Demo;