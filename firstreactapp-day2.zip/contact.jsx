import React from 'react'
class Contact extends React.Component {
    render() {
        return (
            <div>
                <h1>Contact Component</h1>
                <hr/>
                <ul>
                    {this.props.hobbies.map((hobby, i)=> <li key={i}>{hobby}</li>)}
                </ul>
            </div>
        )
    }
}
export default Contact;